package com.hari.test.japsertest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JapsertestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JapsertestApplication.class, args);
	}

}
