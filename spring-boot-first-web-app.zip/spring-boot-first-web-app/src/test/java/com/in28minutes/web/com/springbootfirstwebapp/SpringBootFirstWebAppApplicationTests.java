package com.in28minutes.web.com.springbootfirstwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirstWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
